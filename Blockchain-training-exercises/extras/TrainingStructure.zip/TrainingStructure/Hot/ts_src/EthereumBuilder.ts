import {Builder} from './builder';
import {WalletData} from "./EthUtils";


export class EthereumBuilder extends Builder {

    //Contains all necessary information for account. filled out with .init()
    data: WalletData;

    constructor(xpub: any, path: any) {
        super(xpub, path);
    }
    init: () => Promise<this> = async () => {
        return this
    };

    //Method that logs all relevant wallet data.
    show: () => Promise<any> = async () => {
        return this
    };

    //Base method used to create an unsigned transaction object. Writes a signature request to ./data/signature_requests.json to be imported to crt-cold for signing.
    //stores the unsigned transaction to this.transaction
    async createTransaction(targetAddress: any, value: number, {...params} = {}): Promise<any> {

    }

    //Base method used to sign a transaction. After a signature response is created by crt-cold either manually or with the API, this reconstructs the transaction using a preimage and injects the signature
    //to the transaction
    async signTransaction(): Promise<any> {

    };

    //posts the transaction on the testnet and logs a link to view the transaction on the block explorer
    public async postTransaction(transaction: any): Promise<any> {

    }
}

async function main() {
    const args = process.argv;
    if (args.length > 2) {
        if (args[2] == "--sign") {
            console.log("Signing and Posting Transaction!")
            console.log("Transaction Posted!")
        }
    } else {
        console.log("Building Transaction!")
    }
}
main();
