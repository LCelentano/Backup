export type WalletData = {
  rootXpub: string;
  rootXpubPath: string;
  publicKey: string;
  address: string;
  path: string;
  //balance: BigNumber;
  gasFeeData: any
};


