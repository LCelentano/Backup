import fs from "fs";
import { SignatureRequest } from "./SignatureRequest";

export const writeRecords = async (walletData?, signatureRequests?: { preimage: string, signatureRequests: SignatureRequest[] }) => {

}