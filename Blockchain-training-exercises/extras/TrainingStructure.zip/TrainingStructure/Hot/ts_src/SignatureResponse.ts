export interface SignatureResponse {
    publicKey: string;
    path: string;
    curve: string;
    signature: string;
}