"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Builder = void 0;
class Builder {
    xpub;
    path;
    constructor(xpub, path) {
        this.xpub = xpub;
        this.path = path;
    }
}
exports.Builder = Builder;
