class Cold:
    def __init__(self, profile_id: str):
     

    def generate_private_key(self, path: str, salt: str = "") -> str:
        """
        Generates a private key at a given path

        :param path: BIP-44-like HD wallet path
        :param salt: passphrase for added protection or separation for HD wallet keys
        :return: secret key data at the given path of the HD wallet
        """

    def generate_public_key(self, path: str, salt: str = "") -> str:
        """
        Generates a public key at a given path

        :param path: BIP-44-like HD wallet path
        :param salt: passphrase for added protection or separation for HD wallet keys
        :return: public key data at the given path of the HD wallet
        """

    def generate_xprv(self, path: str, salt: str = "") -> str:
        """
        Generates an extended private key at a given path

        :param path: BIP-44-like HD wallet path
        :param salt: passphrase for added protection or separation for HD wallet keys
        :return: bech32-encoded private key data at the given path of the HD wallet that further derive private keys
        """

    def generate_xpub(self, path: str, salt: str = "") -> str:
        """
        Generates an extended public key at a given path

        :param path: BIP-44-like HD wallet path
        :param salt: passphrase for added protection or separation for HD wallet keys
        :return: bech32-encoded public key data at the given path of the HD wallet that further derive public keys
        """

    def sign(self, private_key: str, message: str) -> str:
        """
        Signs a message using the appropriate algorithm for the coin

        :param private_key: secret key used to produce cryptographic signature
        :param message: data that is to be signed
        :return: signature as r and s concatenated as a string
        """

    def generate_cold_mnemonic() -> str:
        """
        Create the base mnemonic to be securely stored. This mnemonic will be used to derive all keys and addresses.

        :return: Twenty-four word mnemonic phrase.
        """
        # if a valid mnemonic exists at file path, read and return it
    
